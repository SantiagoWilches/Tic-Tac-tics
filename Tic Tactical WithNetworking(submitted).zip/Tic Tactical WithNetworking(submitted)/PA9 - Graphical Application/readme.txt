Team Name: The Sleepers

Members:
Ceyel Clark			Lab Section #5
Santiago Wilches	Lab Section #5
Joey Temme			Lab Section #5
Richard Daniels		Lab Section #5

This is the networking version which works most of the time 
on private networks. Boards on both machines are updated
and only one machine is allowed to update the variables. 
Variables are passed between machines in an attempt to keep
the boards synced. Again, this works most of the time.