#include "PA9.h"

int main()
{
	Player player;	sf::Font font;	sf::Text text;	sf::String playerString;	int playerNumber = 0;	int servClient = 0;
	int result = 0; sf::TcpSocket *socket; sf::Packet packet;
	srand((unsigned int)time(NULL));
	setFont(font, text);
	bool play = true;
	while (play)
	{
		result = menu(play);
		if (result == 1)
		{
				quereyPlayers(player, playerNumber, play);
			if (play)
			{
				sf::RenderWindow window(sf::VideoMode::getDesktopMode(), "Tic Tactical", sf::Style::Default);
				playGame(window, font, playerNumber, playerString, text, player, play);
				player.playerOne.clear();
				player.playerTwo.clear();
			}
		}
		if (result == 2)
		{
			printInstructions();
		}
	}
	return 0;
}