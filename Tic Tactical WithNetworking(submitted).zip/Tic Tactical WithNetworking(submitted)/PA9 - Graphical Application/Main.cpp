#include "PA9.h"

int main()
{
	Player player;	sf::Font font;	sf::Text text;	sf::String playerString;	int playerNumber = 0, servClient = 0;
	int result = 0; sf::TcpSocket socket; sf::Packet packet; sf::IpAddress address;
	srand((unsigned int)time(NULL));
	setFont(font, text);
	bool play = true;
	unsigned short port = 12345;
	char option = '\0';
	std::cout << "Server (s), or Client (c)?" << std::endl;
	std::cout << "Initiate the server first." << std::endl;
	std::cin >> option;
	if (option == 's')
	{
		sf::TcpListener listener;
		listener.listen(port);
		std::cout << "Local Address: " << sf::IpAddress::getLocalAddress() << std::endl;
		std::cout << "Server is listening to port " << port << ", waiting for connections... " << std::endl;
		listener.accept(socket);
		servClient = 0;
	}
	else if (option == 'c')
	{
		sf::IpAddress server;
		do
		{
			std::cout << "Type the address or name of the server to connect to: ";
			std::cin >> server;
		} while (server == sf::IpAddress::None);
		socket.connect(server, port);
		address = server;
		servClient = 1;
	}

	while (play)
	{
		result = menu(play);
		if (result == 1)
		{
			if (servClient == 0)
			{
				quereyPlayers(player, playerNumber, play);
				char p2[] = "test";
				p2[0] = ((std::string)player.playerTwo)[0];
				if (socket.send(p2, sizeof(p2)) != sf::Socket::Done)
					cout << "error." << endl;
				if (socket.send(&playerNumber, sizeof(playerNumber)) != sf::Socket::Done)
					cout << "error." << endl;
			}
			if (servClient == 1)
			{
				char packetStr[5]; size_t size; int *num = new int(10);
				if (socket.receive(packetStr, 5, size) == sf::Socket::Done)
				{
					if (packetStr[0] == 'x')
					{
						player.playerTwo.insert(0, "x");
						player.playerOne.insert(0, "o");
					}
					else if (packetStr[0] == 'o')
					{
						player.playerTwo.insert(0, "o");
						player.playerOne.insert(0, "x");
					}
				}
				if (socket.receive(num, sizeof(*num), size) == sf::Socket::Done)
				{
					playerNumber = *num;
				}
			}
			if (play)
			{
				sf::RenderWindow window(sf::VideoMode((sf::VideoMode::getDesktopMode().width)/2,
					sf::VideoMode::getDesktopMode().height), "Tic Tactical", sf::Style::Default);
				playGame(window, font, playerNumber, playerString, text, player, play, servClient, address);
				player.playerOne.clear();
				player.playerTwo.clear();
			}
		}
		if (result == 2)
		{
			printInstructions();
		}
	}
	return 0;
}