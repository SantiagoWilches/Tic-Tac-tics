Team Name: The Sleepers

Members:
Ceyel Clark			Lab Section #5
Santiago Wilches	Lab Section #5
Joey Temme			Lab Section #5
Richard Daniels		Lab Section #5

Submitted solution with networking seperately.

Corrected character select double click issue discovered
in lecture on 26April.